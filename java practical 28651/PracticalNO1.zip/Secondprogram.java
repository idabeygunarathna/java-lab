
package com.mycompany.firstprogram;

public class Secondprogram 
{
    public static void main(String[] args) 
    {
        System.out.println("Your Name");
        System.out.println("Your Degree Program");
    }
}

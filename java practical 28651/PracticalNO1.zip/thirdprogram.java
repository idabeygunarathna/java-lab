
package com.mycompany.firstprogram;

public class thirdprogram 
{
    public static void main(String[] args) 
    {
        for (int i = 0; i < 5; i++) 
        {
            System.out.println("Executing Loop " + i);
        }
    }
}




//while loop

package com.mycompany.firstprogram;

public class thirdprogram 
{
    public static void main(String[] args)
    {
        int i = 0;
        while (i < 5)
        {
            System.out.println("Executing Loop " + i);
            i++;
        }
    }
}


package com.mycompany.practical1;
public class Practical1 
{
       public static void main(String[] args) {
        char grade = 'A';
        switch (grade) {
            case 'A':
                System.out.println("Excellent!");
            case 'D':
                System.out.println("You passed");
            case 'F':
                System.out.println("Better try again");
                break;
            default:
                System.out.println("Invalid grade");
        }
        System.out.println("Your grade is " + grade);
    }

}



Excellent!
You passed
Better try again
Your grade is A



package com.mycompany.practical01;
public class practical01 
{
      public static void main(String[] args) {
        char grade = 'A';
        if (grade == 'A') {
            System.out.println("Excellent!");
        } else if (grade == 'D') {
            System.out.println("You passed");
        } else if (grade == 'F') {
            System.out.println("Better try again");
        } else {
            System.out.println("Invalid grade");
        }
        System.out.println("Your grade is " + grade);
    }  
}



Excellent!
Your grade is A